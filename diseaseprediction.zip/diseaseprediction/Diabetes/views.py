from django.shortcuts import render
from .models import DiabetesPredict

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression

# Create your views here.
def Home(request):

    return render(request,'diabetesData.html')

def DbPredict(request):
    if(request.method == 'POST'):
        Age=request.POST["Age"]
        Pregnancies=request.POST["Pregnancies"]
        Glucose =request.POST["Glucose"]
        BloodPressure=request.POST["BloodPressure"]
        SkinThickness=request.POST["SkinThickness"]
        Insulin=request.POST["Insulin"]
        BMI=request.POST["BMI"]
        DiabetesPedigreeFunction=request.POST["DiabetesPedigreeFunction"]

        df = pd.read_csv(r"static/diabetes.csv")
        df.dropna(inplace=True)
        df.isnull().sum()
        X_train = df[["Age","Pregnancies","Glucose","BloodPressure","SkinThickness","Insulin","BMI","DiabetesPedigreeFunction"]]
        y_train = df[["Outcome"]]
        l = LogisticRegression()
        l.fit(X_train,y_train)
        prediction = l.predict([[Age,Pregnancies,Glucose,BloodPressure,SkinThickness,Insulin,BMI,DiabetesPedigreeFunction]])



        k = DiabetesPredict.objects.create(Age=Age,Pregnancies=Pregnancies,Glucose=Glucose,BloodPressure=BloodPressure,SkinThickness=SkinThickness,Insulin=Insulin,BMI=BMI,DiabetesPedigreeFunction=DiabetesPedigreeFunction)
        k.save()
        if prediction==[1]:
            f = "YOU ARE AFFECTED BY DIABETES"
        else:
            f = "HURRAY! YOU ARE NOT AFFECTED"
    return render(request,'DbPredict.html',{"Data":f,"Age":Age,"Pregnancies":Pregnancies,"Glucose":Glucose,"BloodPressure":BloodPressure,"SkinThickness":SkinThickness,"Insulin":Insulin,"BMI":BMI,"DiabetesPedigreeFunction":DiabetesPedigreeFunction})
