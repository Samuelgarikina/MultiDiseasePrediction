from django.contrib import admin

# Register your models here.
from Diabetes.models import userdata,DiabetesPredict

admin.site.register(userdata)
admin.site.register(DiabetesPredict)
