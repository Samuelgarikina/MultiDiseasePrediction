from django.contrib import admin

# Register your models here.
from lung.models import lungcancerPrediction

admin.site.register(lungcancerPrediction)
