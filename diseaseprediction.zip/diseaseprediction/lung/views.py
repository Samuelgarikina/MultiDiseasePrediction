from django.shortcuts import render
from .models import lungcancerPrediction

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import OrdinalEncoder

# Create your views here.
def lungData(request):
    return render(request,'lungData.html')

def lungPredict(request):
    if(request.method == 'POST'):
        Age=request.POST['Age']
        Gender=request.POST['Gender']
        AirPollution=request.POST['AirPollution']
        Alcoholuse=request.POST['Alcoholuse']
        DustAllergy=request.POST['DustAllergy']
        OccuPationalHazards=request.POST['OccuPationalHazards']
        GeneticRisk=request.POST['GeneticRisk']
        chronicLungDisease=request.POST['chronicLungDisease']
        BalancedDiet=request.POST['BalancedDiet']
        Obesity=request.POST['Obesity']
        Smoking=request.POST['Smoking']
        PassiveSmoker=request.POST['PassiveSmoker']
        ChestPain=request.POST['ChestPain']
        CoughingofBlood=request.POST['CoughingofBlood']
        Fatigue=request.POST['Fatigue']
        WeightLoss=request.POST['WeightLoss']
        ShortnessofBreath=request.POST['ShortnessofBreath']
        Wheezing=request.POST['Wheezing']
        SwallowingDifficulty=request.POST['SwallowingDifficulty']
        ClubbingofFingerNails=request.POST['ClubbingofFingerNails']
        FrequentCold=request.POST['FrequentCold']
        DryCough=request.POST['DryCough']
        Snoring=request.POST['Snoring']



        df = pd.read_csv(r'static/lungs.csv')
        df.dropna(inplace=True)
        ord1 = OrdinalEncoder()
        # fitting encoder
        ord1.fit([df['Level']])
        # transforming the column after fitting
        df["Level"]= ord1.fit_transform(df[["Level"]])

        X_train = df.drop(['Level','total'],axis=1)
        y_train = df[['Level']]
        l = LogisticRegression()
        l.fit(X_train,y_train)
        prediction=l.predict([[Age,Gender,AirPollution,Alcoholuse,DustAllergy,OccuPationalHazards,GeneticRisk,chronicLungDisease,BalancedDiet,Obesity,Smoking,PassiveSmoker,ChestPain,CoughingofBlood,Fatigue,WeightLoss,ShortnessofBreath,Wheezing,SwallowingDifficulty,ClubbingofFingerNails,FrequentCold,DryCough,Snoring]])

        k = lungcancerPrediction.objects.create(Age=Age,Gender=Gender,AirPollution=AirPollution,Alcoholuse=Alcoholuse,DustAllergy=DustAllergy,
                                                     OccuPationalHazards=OccuPationalHazards,GeneticRisk=GeneticRisk,chronicLungDisease=chronicLungDisease,
                                                     BalancedDiet=BalancedDiet,Obesity=Obesity,Smoking=Smoking,PassiveSmoker=PassiveSmoker,ChestPain=ChestPain,
                                                     CoughingofBlood=CoughingofBlood,Fatigue=Fatigue,WeightLoss=WeightLoss,ShortnessofBreath=ShortnessofBreath,
                                                     Wheezing=Wheezing,SwallowingDifficulty=SwallowingDifficulty,ClubbingofFingerNails=ClubbingofFingerNails,
                                                     FrequentCold=FrequentCold,DryCough=DryCough,Snoring=Snoring)
        if prediction==[0.]:
            f = "YOU ARE AFFECTED BY LUNG CANCER"
        elif prediction==[2.]:
            f = "LEVEL OF YOUR DISEASE(LUNG CANCER) IS MEDIUM"
        else:
            f = "HURRAY! YOU ARE NOT AFFECTED BY LUNG CANCER "
    return render(request,'lungPredict.html',{"Data":f,"Age":Age,"Gender":Gender,"AirPollution":AirPollution,"Alcoholuse":Alcoholuse,"DustAllergy":DustAllergy,
                                                 "OccuPationalHazards":OccuPationalHazards,"GeneticRisk":GeneticRisk,"chronicLungDisease":chronicLungDisease,
                                                  "BalancedDiet":BalancedDiet,"Obesity":Obesity,"Smoking":Smoking,"PassiveSmoker":PassiveSmoker,"ChestPain":ChestPain,
                                                  "CoughingofBlood":CoughingofBlood,"Fatigue":Fatigue,"WeightLoss":WeightLoss,"ShortnessofBreath":ShortnessofBreath,
                                                  'Wheezing':Wheezing,"SwallowingDifficulty":SwallowingDifficulty,"ClubbingofFingerNails":ClubbingofFingerNails,
                                                   'FrequentCold':FrequentCold,'DryCough':DryCough,'Snoring':Snoring})
