"""diseaseprediction URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from diseaseprediction import views
from Diabetes.views import Home,DbPredict
from heart.views import hhome,heartPredict
from lung.views import lungData,lungPredict
urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.Index,name="Index"),
    path('login',views.login,name="login"),
    path('selectD',views.selectD,name="selectD"),
    path('register',views.register,name="register"),
    path('diabetesData',Home,name="diabetesData"),
    path('DbPredict',DbPredict,name="Dbpredict"),
    path('heart',hhome,name="hhome"),
    path('heartPredict',heartPredict,name="heartPredict"),
    path('lungData',lungData,name="lungData"),
    path('lungPredict',lungPredict,name="lungPredict")
]
