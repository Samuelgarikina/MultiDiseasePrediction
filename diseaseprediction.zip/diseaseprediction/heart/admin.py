from django.contrib import admin

# Register your models here.
from heart.models import heartPrediction

admin.site.register(heartPrediction)
