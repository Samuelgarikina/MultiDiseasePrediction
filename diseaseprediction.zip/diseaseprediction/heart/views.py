from django.shortcuts import render
from .models import heartPrediction

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression

# Create your views here.
def hhome(request):

    return render(request,'heartData.html')

def heartPredict(request):
    if(request.method == 'POST'):
        age=request.POST["age"]
        sex=request.POST["sex"]
        cp =request.POST["cp"]
        trestbps=request.POST["trestbps"]
        chol=request.POST["chol"]
        fbs=request.POST["fbs"]
        restecg=request.POST["restecg"]
        thalach=request.POST["thalach"]
        exang=request.POST["exang"]
        oldpeak=request.POST["oldpeak"]
        slope=request.POST["slope"]
        ca=request.POST["ca"]
        thal=request.POST["thal"]


        df = pd.read_csv(r"static/heart.csv")
        df.dropna(inplace=True)
        df.isnull().sum()
        X_train = df[['age','sex','cp','trestbps','chol','fbs','restecg','thalach','exang','oldpeak','slope','ca','thal']]
        y_train = df[["target"]]
        l = LogisticRegression()
        l.fit(X_train,y_train)
        prediction = l.predict([[age,sex,cp,trestbps,chol,fbs,restecg,thalach,exang,oldpeak,slope,ca,thal]])



        k = heartPrediction.objects.create(age=age,sex=sex,cp=cp,trestbps=trestbps,chol=chol,fbs=fbs,restecg=restecg,thalach=thalach,exang=exang,oldpeak=oldpeak,slope=slope,ca=ca,thal=thal)
        k.save()
        if prediction==[1]:
            f = "YOU ARE AFFECTED BY HEART DISEASE"
        else:
            f = "HURRAY! YOU ARE NOT AFFECTED BY HEART DISEASE"
    return render(request,'heartPredict.html',{"Data":f,'age':age,'sex':sex,'cp':cp,'trestbps':trestbps,'chol':chol,'fbs':fbs,'restecg':restecg,'thalach':thalach,'exang':exang,'oldpeak':oldpeak,'slope':slope,'ca':ca,'thal':thal})

# Create your views here.
